<h2>Project Details Goes Here</h2>
    <form>
        <label name="Project Status">Project Status</label>
        <select class="form-control">
            <option value="Select Ststus">Select Ststus</option>
            <option value="Done">Done</option>
            <option value="In-Development">In Development</option>
            <option value="Not-Yet-Started ">Not Yet Started</option>
            
        </select>
    </form>