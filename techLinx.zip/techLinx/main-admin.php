<?php include 'mainHeader.php'; ?>
<body>
    <?php include 'sidebar.php'; ?>
    <div class="content" id="content">
        <?php include 'navbar.php'; ?>
        <div class="container mt-4" id="main-content">
            <?php include 'dashboard.php'; ?>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>
