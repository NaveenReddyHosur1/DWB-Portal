<div id="content-area">
    <?php include('dashboard.php'); ?>  <!-- Default Content -->
</div>
