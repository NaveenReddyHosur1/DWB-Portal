<nav class="navbar navbar-expand-lg  fixed-top">
    <div class="container-fluid">
        <span class="navbar-brand">
            <img src="https://techlinx.ai/images/logo-techlinx.jpg" class="img-fluid" style="width:130px;">
        </span>
    </div>
</nav>
