// Load Content into Main Section
function loadContent(page) {
    fetch(page)
        .then(response => response.text())
        .then(data => {
            document.getElementById('content-area').innerHTML = data;
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
}

// Scroll selected section to appear right after the navbar
function scrollToSection(sectionId) {
    let sidebar = document.querySelector(".sidebar");
    let section = document.getElementById(sectionId);
    let navbarHeight = document.querySelector(".navbar").offsetHeight;

    if (sidebar && section) {
        let sectionTop = section.offsetTop; // Position of the section inside the sidebar

        sidebar.scrollTo({
            top: sectionTop - navbarHeight, // Adjust for navbar height
            behavior: "smooth"
        });
    }
}
