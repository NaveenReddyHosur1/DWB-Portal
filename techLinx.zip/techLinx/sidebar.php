<div class="sidebar" id="sidebar">
    <a href="#" onclick="loadContent('dashboard.php')">Dashboard</a>

    <h5 class="text-white px-3" id="cx" onclick="scrollToSection('cx')">CX</h5>
    <a href="#" onclick="loadContent('projectDetails.php')">Project Details</a>
    <a href="#" onclick="loadContent('tab2.php')">Tab 2</a>
    <a href="#" onclick="loadContent('tab3.php')">Tab 3</a>
    <a href="#" onclick="loadContent('tab4.php')">Tab 4</a>
    <a href="#" onclick="loadContent('tab5.php')">Tab 5</a>

    <h5 class="text-white px-3 mt-5" id="rx" onclick="scrollToSection('rx')">RX</h5>
    <a href="#" onclick="loadContent('tab6.php')">Tab 6</a>
    <a href="#" onclick="loadContent('tab7.php')">Tab 7</a>
    <a href="#" onclick="loadContent('tab8.php')">Tab 8</a>
    <a href="#" onclick="loadContent('tab9.php')">Tab 9</a>
    <a href="#" onclick="loadContent('tab10.php')">Tab 10</a>

    <h5 class="text-white px-3 mt-5" id="ix" onclick="scrollToSection('ix')">IX</h5>
    <a href="#" onclick="loadContent('tab11.php')">Tab 11</a>
    <a href="#" onclick="loadContent('tab12.php')">Tab 12</a>
    <a href="#" onclick="loadContent('tab13.php')">Tab 13</a>
    <a href="#" onclick="loadContent('tab14.php')">Tab 14</a>
    <a href="#" onclick="loadContent('tab15.php')">Tab 15</a>
</div>
