<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Techlinx Super-Admin</title>
    <link rel="stylesheet" href="style.css">
    <?php include('header.php'); ?>
</head>
<body>
    <?php include('navbar.php'); ?> <!-- Navbar at the top -->

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar">
                <?php include('sidebar.php'); ?>
            </div>

            <!-- Main Content Area -->
            <div class="col-md-9 col-lg-10 main-content">
                <div id="content-area">
                    <?php include('dashboard.php'); ?>  <!-- Default page -->
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
