<h2>Dashboard</h2>
<p>Welcome to the Super Admin Dashboard!</p>
<section>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="shadow p-3 bg-primary-subtle rounded-3 border-0">
                    <h4 class="text-dark"><a href="#cx"> <br>Candidate Experience</a></h4>
                </div>
            </div>
            <div class="col">
                <div class="shadow p-3 bg-primary-subtle rounded-3 border-0">
                    <h4 class="text-dark"><a href="#rx"> <br>Recruiter Experience</a></h4>
                </div>
            </div>
            <div class="col">
                <div class="shadow p-3 bg-primary-subtle rounded-3 border-0">
                    <h4 class="text-dark"><a href="#ix"> <br>Integration Experience</a></h4>
                </div>
            </div>
        </div>
    </div>
</section>
